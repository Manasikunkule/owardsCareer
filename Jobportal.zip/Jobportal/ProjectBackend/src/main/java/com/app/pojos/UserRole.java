package com.app.pojos;

public enum UserRole {
ADMIN,APPLICANT,COMPANY
}
