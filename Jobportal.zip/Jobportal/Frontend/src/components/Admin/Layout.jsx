import React from "react";
import Sidebar from "../../components/Admin/Sidebar";

const AdminDashboardLayout = () => {
  return (
    <>
      <Sidebar />
    </>
  );
};

export default AdminDashboardLayout;
