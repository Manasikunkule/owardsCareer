import React from "react";
import Sidebar from "../../components/Employer/Sidebar";

const DashboardLayout = () => {
  return (
    <>
      <Sidebar />
    </>
  );
};

export default DashboardLayout;
